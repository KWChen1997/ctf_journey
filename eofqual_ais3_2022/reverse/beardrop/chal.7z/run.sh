#!/bin/zsh

/usr/sbin/dropbear -E &

/bin/zsh
